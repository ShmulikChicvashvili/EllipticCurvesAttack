
#ifndef NTL_vec_vec_ZZ_pE__H
#define NTL_vec_vec_ZZ_pE__H

#include <NTL/vec_ZZ_pE.h>

NTL_OPEN_NNS

typedef Vec< Vec<ZZ_pE> > vec_vec_ZZ_pE;

NTL_CLOSE_NNS

#endif
